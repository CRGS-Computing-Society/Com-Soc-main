﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheGauntlet.Battle
{
    public enum StatusEffect
    {
        None,
        Burn,
        Poison,
        Stun,
        Regen
    }
}
