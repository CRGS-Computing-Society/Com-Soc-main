Instructions:

Upon starting the game you’ll be prompted to select a class. Each class have different stats and a unique special ability:

Tank:
Health > 580
Attack > 6
Defence > 9
Speed > 2 
Special move > Ultimate slam > Charges into the target, stunning them.

Ninja:
Health > 540
Attack > 8
Defence > 3
Speed > 10
Special Move > Shinobi > Uses an ancient technique to poison the target.

Mage:
Health > 560
Attack > 8
Defence > 5
Speed > 6
Special Move > Fireball > Burns the target.

Dark Mage:
Health > 590
Attack > 9
Defence > 2
Speed > 5
Special Move > Life Drain > Steals the target’s health.

The first part of the game is the overworld. You’ll find your character (O) in a grid, surrounded by chests (*). You must use WASD to move your character to collect as many chests as you can in your allotted moves. The amount of moves you have is 10 + the speed of your class.

Each chest contains an item that buffs your stats. At the end of this phase your buffs will be applied.

Next you’ll face off against an endless onslaught of enemies. You can use your class’s abilities to attack the enemies, and they’ll use their own attacks against you. You must last as long as possible as the enemies progressively get more and more powerful.

Good luck noobs.