﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheGauntlet
{
	public enum GameState
	{
		ChoosingClass,
		Overworld,
		Battle
	}
}
