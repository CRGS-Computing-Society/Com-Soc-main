﻿using System;

namespace TheGauntlet
{
    internal static class Program
    {
        private static void Main()
        {
            var game = new Game();
            game.Start();
        }
    }
}
